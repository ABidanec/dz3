<?php
/**
 * Created by PhpStorm.
 * User: Александр
 * Date: 08.09.2015
 * Time: 10:31
 */

class FileManager{
    private $arrayFileName;
    private $filesList;

    function __construct($nameDir){
        $dir = opendir($nameDir);
        while ($marker = readdir($dir)) {
            if($marker === '.' or $marker === '..') continue;

            $this->filesList[] = $marker;
        }
    }
    function getFilesList(){
        return $this->filesList;
    }

    function getListA(){
        echo '<ul>';
        foreach ($this->filesList as $f) {
            $f = iconv("WINDOWS-1251","UTF-8",$f);
            echo "<li>".$f."
            <a href='?action=write&file=".$f."'>Редактировать</a>
            <a href='?action=delete&file=".$f."'>Удалить</a> </li>";
        }

        echo '</ul>';
    }
}