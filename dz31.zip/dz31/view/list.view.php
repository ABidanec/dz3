<p><a href="?action=create">Создать файл</a></p>
<?php
$fm = new FileManager('files');
$fm->getListA();