<?php

if($_GET['file']){
    $file = trim(strip_tags($_GET['file']));
}