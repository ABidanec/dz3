<p></p><a href="?action=format">Создать дамп таблиц БД в разных форматах</a></p>
<p></p><a href="?action=list">Редактирование файлов</a></p>