<?php
if($_GET['action' ] == 'delete' or isset($_GET[file])){
    $file = trim(strip_tags($_GET['file']));
    unlink('files/'.$file);
}
